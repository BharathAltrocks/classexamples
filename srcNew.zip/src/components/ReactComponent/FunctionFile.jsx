import React, { Component } from 'react'

export default class FunctionFile extends Component {
  render() {
    return (
      <div>FunctionFile</div>
    )
  }
}
