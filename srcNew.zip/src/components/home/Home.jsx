import React from 'react'
function Home() {
  return (
    <div>
      Welcome All!!
    </div>
  )
}

export default Home